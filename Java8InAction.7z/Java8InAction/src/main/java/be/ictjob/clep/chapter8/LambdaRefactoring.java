package chapter8;

public class LambdaRefactoring extends MySuperClass {
    public static void main(String[] args) {
        LambdaRefactoring lambdaRefactoring = new LambdaRefactoring();
        lambdaRefactoring.doIt();
    }

    private void doIt() {
        Runnable r = () -> System.out.println("lambda this: " + this.getClass().getName());
        r.run();

        Runnable r1 = () -> System.out.println("lambda super: " + super.getClass().getName());
        r1.run();

        Runnable r2 = new Runnable() {
            @Override
            public void run() {
                System.out.println("anonymous class this: " + this.getClass().getName());
            }
        };
        r2.run();

        Runnable r3 = new Runnable() {
            @Override
            public void run() {
                System.out.println("anonymous class super: " + super.getClass().getName());
            }
        };
        r3.run();

        int a = 10;
        Runnable r4 = new Runnable() {
            public void run() {
//                a += 2; // KO
                int a = 2;
                System.out.println("anonymous class shadow variable: "+a);
            }
        };
        r4.run();

        /*
        int b = 10;
        Runnable r5 = () -> {
//            int b = 3; // KO
//            b += 3; // KO
            System.out.println("lambda shadow variable: " + b);
        };
        r5.run();
        */
    }
}
