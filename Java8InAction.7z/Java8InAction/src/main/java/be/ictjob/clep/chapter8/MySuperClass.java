package chapter8;

public class MySuperClass {
    public MySuperClass() {
        System.out.println("I am in the constructor of My SuperClass");
    }
}
